# Element Powers (Fabric 1.21.11)

Every player gets ONE random element (no duplicates, rolled once), with 4 ability levels.
No items needed: abilities are keybinds on the player.

## Controls (change in Options > Controls > Key Binds > Element Powers)
- R = use selected ability
- G = switch between unlocked abilities

## Commands
- /powers roll        (OP) give an unused random element to every online player without one. Existing elements never change.
- /powers reset       (OP) wipe everything
- /powers levelup <player>   (OP) unlock next ability
- /powers leveldown <player> (OP)
- /powers info        shows your element and level

Max 12 players (12 elements) so nobody shares a power.
Data is saved in the world folder: elementpowers.json

## Server notes
- Everyone needs the mod + Fabric API installed (keybinds are client-side).
- Flight abilities (Wind L3, Magnetism L4) can kick players for "flying": set allow-flight=true in server.properties.

## Build
Automatic (GitHub): push this folder to a GitHub repo -> Actions tab -> "Build mod" -> download artifact `elementpowers-jar`.
Local: ./gradlew build  (needs JDK 21)  -> build/libs/elementpowers-1.0.0.jar
(Use the jar WITHOUT "-sources" in the name.)
